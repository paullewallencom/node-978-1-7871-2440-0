(function(){
    'use strict';

    angular
    .module('bikesGallery', ['ui.router','lbServices']);
    
})();
