module.exports = function(Gallery) {

};
